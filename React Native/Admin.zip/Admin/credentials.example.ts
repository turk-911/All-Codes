export const FIREBASE_API_KEY = "your api key";
export const AUTH_DOMAIN = "your auth domain";
export const PROJECT_ID = "your project id";
export const STORAGE_BUCKET = "your storage bucket id";
export const MESSAGING_SENDER_ID = "your messaging sender id";
export const APP_ID = "your app id";